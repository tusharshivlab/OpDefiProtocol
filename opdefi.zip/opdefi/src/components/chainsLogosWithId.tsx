import { BNBLogo, ETHLogo } from "./Logos";

export const ChainLogosWithID = [
  {
    id: 1,
    name: "Lido",
    icon: 'https://tokens.1inch.io/0x5a98fcbea516cf06857215779fd812ca3bef1b32.png',
    value: "0x5a98fcbea516cf06857215779fd812ca3bef1b32",
  },

  {
    id: 2,
    name: "Convex Finance",
    icon: 'https://tokens.1inch.io/0x4e3fbd56cd56c3e72c1403e103b45db9da5b9d2b.png',
    value: "0x4e3fbd56cd56c3e72c1403e103b45db9da5b9d2b",
  },
];
